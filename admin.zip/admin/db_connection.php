<?php
$host = "localhost";
$username = "root";
$passsword = "";
$dbname = "srit";

$conn = new mysqli($host, $username, $passsword, $dbname);

?>